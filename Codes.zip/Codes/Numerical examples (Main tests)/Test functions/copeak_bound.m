function [lx,lu]= copeak_bound
d = 2;
lx=0*ones(1,d);
lu=1*ones(1,d);
end