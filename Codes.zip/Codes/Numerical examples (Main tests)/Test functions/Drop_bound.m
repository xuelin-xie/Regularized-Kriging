function [lx,lu]= Drop_bound
d = 2;
lx=-1*ones(1,d);
lu=1*ones(1,d);
end