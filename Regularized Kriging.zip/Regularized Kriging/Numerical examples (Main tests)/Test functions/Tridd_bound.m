function [lx,lu]=Tridd_bound
d = 8;
lx=-1*ones(1,d);
lu=1*ones(1,d);

end