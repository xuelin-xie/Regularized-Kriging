function [ XL,XU ] = HTCS_bound(  )
XL=[0.05,0.25,2];
XU=[2,1.3,15];
end

