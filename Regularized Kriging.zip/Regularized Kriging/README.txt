Notice:

1. This file basically contains all the test code, and the optimizer for solving the regularized Kriging model is improved based on the DACE package [1].
[1] Lophaven, S.N., Nielsen, H.B., J., S.: DACE - A Matlab Kriging Toolbox, 2.0, Informatics and Mathematical Modelling, Technical University of Denmark, DTU (2002)

2. Running the program on different computers may result in different outcomes, despite setting the random seed. There may be cases where the regularized Kriging model is less effective compared to the ordinary Kriging model, but this does not necessarily imply that our method is unsuitable for other problems.

3. As regularized Kriging involves cross-validation, the number of initial points for constructing the Kriging model in each subset should not be too small because it can cause the failure of model construction.

If you have any questions, please feel free to contact us: xl.xie@whu.edu.cn (Xuelin Xie).

Hope everything goes well with you！



