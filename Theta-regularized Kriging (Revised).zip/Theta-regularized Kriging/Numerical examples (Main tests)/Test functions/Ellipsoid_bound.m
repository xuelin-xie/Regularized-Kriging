function [lx,lu]=Ellipsoid_bound
d=18;
lx=0*ones(1,d);
lu=1*ones(1,d);  % 0.6
end