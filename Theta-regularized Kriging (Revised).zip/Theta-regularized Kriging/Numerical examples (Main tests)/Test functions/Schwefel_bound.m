function [lx,lu]=Schwefel_bound
d=12;
lx=-1*ones(1,d);
lu=1*ones(1,d);

end