Notice:
1. This file basically contains all the test code, and the optimizer for solving the regularized Kriging model is improved based on the DACE package [1].
[1] Lophaven, S.N., Nielsen, H.B., J., S.: DACE - A Matlab Kriging Toolbox, 2.0, Informatics and Mathematical Modelling, Technical University of Denmark, DTU (2002)
2. You can simply run the "Function_test" function to execute our demo. Running the program on different computers may result in different outcomes, despite setting the random seed. There may be cases where the TRK model is less effective compared to the Universal Kriging or PBK model, but this does not necessarily imply that our method is unsuitable for other problems.
3. As TRK involves cross-validation, the number of initial points for constructing the Kriging model in each subset should not be too small because it can cause the failure of model construction.
4. We have updated the code; 1D or 2D interpolation can now be visualized using our plotting function. (Adjusted on April 16, 2026)
5. It should be noted that when manual parameter tuning is selected, different test functions require the user to perform fine-tuning.

How to Cite：
If you find this code or our work helpful, we would really appreciate a citation to our paper. Thank you!
Paper citation: Xuelin Xie, Xiliang Lu. Theta-regularized Kriging: Modelling and Algorithms. Appl. Math. Model., 2024, 136: 115627. https://doi.org/10.1016/j.apm.2024.07.034
@article{xie2024theta,
  title={Theta-regularized Kriging: Modeling and algorithms},
  author={Xie, Xuelin and Lu, Xiliang},
  journal={Applied Mathematical Modelling},
  volume={136},
  pages={115627},
  year={2024},
  publisher={Elsevier},
  doi={10.1016/j.apm.2024.07.034}
}

Contact：
If you have any questions, please feel free to contact us: xl.xie@whu.edu.cn (Xuelin Xie).
Hope everything goes well with you！

