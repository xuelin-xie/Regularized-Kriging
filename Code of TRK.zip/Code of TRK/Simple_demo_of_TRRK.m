clc
clear;
addpath(genpath(pwd));

setdemorandstream(pi);
problem.f=@morcaf95a;
[XL,XU]=morcaf95a_bound();
bounds=[XL;XU];
dim=size(bounds,2); 
pointnum=60;   %60/ 90

%% Copyright: Xuelin Xie (xl.xie@whu.edu.cn)

%% Sampling and evaluation points
S = LHD(XL, XU, pointnum); 
Y = callobj(problem.f, S);
EX = LHD(XL, XU, 5000);  
EY = callobj(problem.f, EX); 

%% Finding the optimal regularization parameters
choose = 1;  % (1: Manual adjustment; 2: GSCV Method)
if choose==1
    %%%% !!!! Notice: morcaf95a function best paramaters %%%% 
    % TR-RK
    TR_bestmu = 100;
else
    TR_bestmu = OptRPR(S,Y);
end

%% UK
fprintf('\n========== Building UK Model ==========\n');
tic; 
krig1 = buildKRG(S, Y); 
t1 = toc;
UK = predictor(EX, krig1);
UR2 = 1 - sum((EY-UK).^2) / sum((EY-mean(EY)).^2);
URMSE1 = sqrt(mean((EY-UK).^2));
UMAE1 = mean(abs(EY-UK));
fprintf('UK - R²: %.6f, RMSE: %.6e, MAE: %.6e, Time: %.4f sec\n', UR2, URMSE1, UMAE1, t1);

%% TR-RK
fprintf('\n========== Building TR-RK Model ==========\n');
tic; 
krig3 = buildKRGRPeT(S, Y, TR_bestmu); 
t3 = toc;
TRRK = predictor(EX, krig3);
TRRR2 = 1 - sum((EY-TRRK).^2) / sum((EY-mean(EY)).^2);
TRRMSE3 = sqrt(mean((EY-TRRK).^2));
TRMAE3 = mean(abs(EY-TRRK));
fprintf('TR-RK - R²: %.6f, RMSE: %.6e, MAE: %.6e, Time: %.4f sec\n', TRRR2, TRRMSE3, TRMAE3, t3);

%% ==================== Results Display ====================
method_names = {'UK', 'TR-RK'};
R2_values = [UR2, TRRR2];
RMSE_values = [URMSE1, TRRMSE3];
MAE_values = [UMAE1, TRMAE3];
time_values = [t1, t3];

fprintf('\n');
fprintf('================================================================================\n');
fprintf('                         Kriging Model Comparison Results\n');
fprintf('================================================================================\n');
fprintf('Test Function: morcaf95a  |  Sample Size: %d\n', pointnum);
fprintf('================================================================================\n\n');

% R² Results
fprintf('【R² (Coefficient of Determination) - Higher is Better】\n');
fprintf('--------------------------------------------------------------------\n');
fprintf('%-10s | %12s\n', 'Method', 'Value');
fprintf('--------------------------------------------------------------------\n');
for i = 1:2
    fprintf('%-10s | %12.6f\n', method_names{i}, R2_values(i));
end
fprintf('--------------------------------------------------------------------\n\n');

% RMSE Results
fprintf('【RMSE (Root Mean Square Error) - Lower is Better】\n');
fprintf('--------------------------------------------------------------------\n');
fprintf('%-10s | %12s\n', 'Method', 'Value');
fprintf('--------------------------------------------------------------------\n');
for i = 1:2
    fprintf('%-10s | %12.6e\n', method_names{i}, RMSE_values(i));
end
fprintf('--------------------------------------------------------------------\n\n');

% MAE Results
fprintf('【MAE (Mean Absolute Error) - Lower is Better】\n');
fprintf('--------------------------------------------------------------------\n');
fprintf('%-10s | %12s\n', 'Method', 'Value');
fprintf('--------------------------------------------------------------------\n');
for i = 1:2
    fprintf('%-10s | %12.6e\n', method_names{i}, MAE_values(i));
end
fprintf('--------------------------------------------------------------------\n\n');

% CPU Time Results
fprintf('【CPU Time (seconds) - Lower is Better】\n');
fprintf('--------------------------------------------------------------------\n');
fprintf('%-10s | %12s\n', 'Method', 'Value');
fprintf('--------------------------------------------------------------------\n');
for i = 1:2
    fprintf('%-10s | %12.6f\n', method_names{i}, time_values(i));
end
fprintf('--------------------------------------------------------------------\n');

% Find the optimal method
[~, best_R2_idx] = max(R2_values);
[~, best_RMSE_idx] = min(RMSE_values);
[~, best_MAE_idx] = min(MAE_values);
[~, best_time_idx] = min(time_values);

fprintf('\n【Best Performance Summary】\n');
fprintf('================================================================================\n');
fprintf('✓ Best R²:    %s (%.6f)\n', method_names{best_R2_idx}, R2_values(best_R2_idx));
fprintf('✓ Best RMSE:  %s (%.6e)\n', method_names{best_RMSE_idx}, RMSE_values(best_RMSE_idx));
fprintf('✓ Best MAE:   %s (%.6e)\n', method_names{best_MAE_idx}, MAE_values(best_MAE_idx));
fprintf('✓ Best Speed: %s (%.6f sec)\n', method_names{best_time_idx}, time_values(best_time_idx));
fprintf('================================================================================\n');

%% Interpolated Image - UK vs TR-RK Comparison

% Collect models and their metrics
krig_models = {krig1, krig3};
model_names = {'UK', 'TR-RK'};
metrics.R2 = [UR2, TRRR2];
metrics.RMSE = [URMSE1, TRRMSE3];

% Call comparison function
compare_kriging_models(krig_models, model_names, problem, bounds, S, Y, metrics, pointnum);