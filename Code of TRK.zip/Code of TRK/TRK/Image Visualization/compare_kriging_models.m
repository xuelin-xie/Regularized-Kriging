function compare_kriging_models(krig_models, model_names, problem, bounds, S, Y, metrics, pointnum)
    % Compare multiple Kriging models in subplot layout (Enhanced Visualization)
    % Input:
    %   krig_models - Cell array of trained Kriging models
    %   model_names - Cell array of model names
    %   problem     - Problem structure containing f function
    %   bounds      - Boundaries [XL; XU]
    %   S           - Training point coordinates
    %   Y           - Training point values
    %   metrics     - Structure containing R2 and RMSE values for each model
    %   pointnum    - Number of training points (for title)
    
    XL = bounds(1,:);
    XU = bounds(2,:);
    dim = size(bounds, 2);
    n_models = length(krig_models);
    
    % Professional color palette
    colors = {[0.1216, 0.4667, 0.7059], ...  % Blue
              [0.8392, 0.1529, 0.1569], ...  % Red
              [0.1725, 0.6275, 0.1725], ...  % Green
              [0.5804, 0.4039, 0.7412], ...  % Purple
              [0.9020, 0.6235, 0.0000], ...  % Orange
              [0.4941, 0.1843, 0.5569], ...  % Magenta
              [0.3010, 0.7450, 0.9330]};     % Cyan
    
    if dim == 1
        % ========== 1D Case ==========
        x = linspace(XL, XU, 1000)';
        y_true = callobj(problem.f, x);
        
        % Total subplots: n_models + 2 (true function + RMSE bar chart)
        n_plots = n_models + 2;
        if n_plots <= 3
            n_cols = n_plots;
        elseif n_plots <= 6
            n_cols = 3;
        else
            n_cols = 4;
        end
        n_rows = ceil(n_plots / n_cols);
        
        fig = figure('Name', 'Kriging Models Comparison', 'NumberTitle', 'off', ...
                    'Position', [100, 100, 1400, 800], 'Color', 'white');
        
        % Subplot 1: True Function
        ax1 = subplot(n_rows, n_cols, 1);
        plot(x, y_true, 'k-', 'LineWidth', 2.5);
        xlabel('x', 'FontSize', 12, 'FontWeight', 'bold');
        ylabel('f(x)', 'FontSize', 12, 'FontWeight', 'bold');
        title('True Function', 'FontSize', 13, 'FontWeight', 'bold');
        grid on;
        set(ax1, 'GridLineStyle', ':', 'GridAlpha', 0.4, 'FontSize', 11, 'Box', 'on');
        
        % Subplots for each model
        for i = 1:n_models
            ax = subplot(n_rows, n_cols, i+1);
            y_pred = predictor(x, krig_models{i});
            
            % Plot prediction
            plot(x, y_pred, '-', 'Color', colors{mod(i-1, length(colors))+1}, ...
                'LineWidth', 2, 'DisplayName', 'Prediction'); hold on;
            
            % Plot training points
            scatter(S, Y, 60, colors{mod(i-1, length(colors))+1}, ...
                   'filled', 'MarkerEdgeColor', 'k', 'LineWidth', 0.8, 'MarkerFaceAlpha', 0.7);
            
            xlabel('x', 'FontSize', 11, 'FontWeight', 'bold');
            ylabel('f(x)', 'FontSize', 11, 'FontWeight', 'bold');
            
            % Color-code title based on R² performance
            if metrics.R2(i) == max(metrics.R2)
                title_color = [0.85, 0.33, 0.10];
                title_text = sprintf('★ %s (R²=%.4f)', model_names{i}, metrics.R2(i));
            else
                title_color = [0.3, 0.3, 0.3];
                title_text = sprintf('%s (R²=%.4f)', model_names{i}, metrics.R2(i));
            end
            title(title_text, 'FontSize', 11, 'FontWeight', 'bold', 'Color', title_color);
            grid on;
            set(ax, 'GridLineStyle', ':', 'GridAlpha', 0.4, 'FontSize', 10, 'Box', 'on');
            legend('Prediction', 'Training Points', 'Location', 'best', 'FontSize', 8);
            hold off;
        end
        
        % Last subplot: RMSE Comparison Bar Chart
        ax_last = subplot(n_rows, n_cols, n_models+2);
        bar_handle = bar(metrics.RMSE, 'FaceColor', [0.3010, 0.7450, 0.9330], ...
                        'EdgeColor', [0.2, 0.2, 0.2], 'LineWidth', 1.2, 'BarWidth', 0.5);
        
        % Highlight the best bar
        [~, best_idx] = min(metrics.RMSE);
        bar_handle.CData(best_idx, :) = [0.85, 0.33, 0.10];
        
        set(gca, 'XTickLabel', model_names, 'FontSize', 10, 'FontWeight', 'bold');
        ylabel('RMSE', 'FontSize', 12, 'FontWeight', 'bold');
        title('RMSE Comparison', 'FontSize', 12, 'FontWeight', 'bold');
        grid on;
        set(gca, 'GridLineStyle', ':', 'GridAlpha', 0.4, 'Box', 'on');
        
        % Add value labels on bars
        for i = 1:n_models
            text(i, metrics.RMSE(i), sprintf('%.3e', metrics.RMSE(i)), ...
                'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
                'FontSize', 9, 'FontWeight', 'bold', 'Color', [0.2, 0.2, 0.2]);
        end
        
        sgtitle(sprintf('Kriging Models Comparison - %s Function (%d training points)', ...
            upper(func2str(problem.f)), pointnum), 'FontSize', 14, 'FontWeight', 'bold');
        
    elseif dim == 2
        % ========== 2D Case ==========
        n_grid = 60;
        x1 = linspace(XL(1), XU(1), n_grid);
        x2 = linspace(XL(2), XU(2), n_grid);
        [X1, X2] = meshgrid(x1, x2);
        X_grid = [X1(:), X2(:)];
        
        % True function
        Y_true = callobj(problem.f, X_grid);
        Y_true_surf = reshape(Y_true, n_grid, n_grid);
        
        % Total subplots: n_models + 2 (true function + RMSE bar chart)
        n_plots = n_models + 2;
        % 智能布局：2-4个模型用2x3，5-6个模型用3x3
        if n_plots <= 4
            n_cols = 2;
            n_rows = 2;
        elseif n_plots <= 6
            n_cols = 3;
            n_rows = 2;
        else
            n_cols = 3;
            n_rows = 3;
        end
        
        fig = figure('Name', 'Kriging Models Comparison', 'NumberTitle', 'off', ...
                     'Position', [50, 50, 1400, 900], 'Color', 'white');
        
        % Colormap for surfaces
        cmap = parula(256);
        
        % Subplot 1: True Function Surface
        ax1 = subplot(n_rows, n_cols, 1);
        surf(X1, X2, Y_true_surf, 'EdgeColor', 'none', 'FaceAlpha', 0.95);
        colormap(ax1, cmap);
        colorbar('Location', 'east', 'FontSize', 9);
        xlabel('x_1', 'FontSize', 10, 'FontWeight', 'bold');
        ylabel('x_2', 'FontSize', 10, 'FontWeight', 'bold');
        zlabel('f(x)', 'FontSize', 10, 'FontWeight', 'bold');
        title('True Function', 'FontSize', 12, 'FontWeight', 'bold');
        grid on;
        view(45, 30);
        
        % Subplots for each model surface
        for i = 1:n_models
            ax = subplot(n_rows, n_cols, i+1);
            Y_pred = predictor(X_grid, krig_models{i});
            Y_pred_surf = reshape(Y_pred, n_grid, n_grid);
            surf(X1, X2, Y_pred_surf, 'EdgeColor', 'none', 'FaceAlpha', 0.95);
            colormap(ax, cmap);
            colorbar('Location', 'east', 'FontSize', 9);
            xlabel('x_1', 'FontSize', 10, 'FontWeight', 'bold');
            ylabel('x_2', 'FontSize', 10, 'FontWeight', 'bold');
            zlabel('Prediction', 'FontSize', 10, 'FontWeight', 'bold');
            
            % Color-code title based on R² performance
            if metrics.R2(i) == max(metrics.R2)
                title_color = [0.85, 0.33, 0.10];
                title_text = sprintf('★ %s (R²=%.4f)', model_names{i}, metrics.R2(i));
            else
                title_color = [0.3, 0.3, 0.3];
                title_text = sprintf('%s (R²=%.4f)', model_names{i}, metrics.R2(i));
            end
            title(title_text, 'FontSize', 11, 'FontWeight', 'bold', 'Color', title_color);
            grid on;
            view(45, 30);
        end
        
        % Last subplot: RMSE Comparison Bar Chart
        ax_last = subplot(n_rows, n_cols, n_models+2);
        bar_handle = bar(metrics.RMSE, 'FaceColor', [0.3010, 0.7450, 0.9330], ...
                        'EdgeColor', [0.2, 0.2, 0.2], 'LineWidth', 1.2, 'BarWidth', 0.5);
        
        % Highlight the best bar
        [~, best_idx] = min(metrics.RMSE);
        bar_handle.CData(best_idx, :) = [0.85, 0.33, 0.10];
        
        set(gca, 'XTickLabel', model_names, 'FontSize', 10, 'FontWeight', 'bold');
        ylabel('RMSE', 'FontSize', 12, 'FontWeight', 'bold');
        title('RMSE Comparison', 'FontSize', 12, 'FontWeight', 'bold');
        grid on;
        set(gca, 'GridLineStyle', ':', 'GridAlpha', 0.4, 'Box', 'on');
        
        % Add value labels on bars
        for i = 1:n_models
            text(i, metrics.RMSE(i), sprintf('%.3e', metrics.RMSE(i)), ...
                'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
                'FontSize', 9, 'FontWeight', 'bold');
        end
        
        % Main title
        sgtitle(sprintf('Kriging Models Comparison - %s Function (%d training points)', ...
            upper(func2str(problem.f)), pointnum), 'FontSize', 14, 'FontWeight', 'bold');
        
    else
        error('Only 1D and 2D problems are supported for visualization. Current dimension: %d', dim);
    end
    
end