function plot_kriging(krig_model, problem, bounds, S, Y, model_name, n_validate)
    % 通用Kriging模型可视化函数（含验证点对比）
    % 输入：
    %   krig_model - 训练好的Kriging模型
    %   problem    - 问题结构体，包含f函数
    %   bounds     - 边界 [XL; XU]
    %   S          - 训练点坐标
    %   Y          - 训练点值
    %   model_name - 模型名称（字符串）
    %   n_validate - 验证点数量（可选，默认50）
    
    if nargin < 7
        n_validate = 500;
    end
    
    XL = bounds(1,:);
    XU = bounds(2,:);
    dim = size(bounds, 2);
    
    % 生成验证点
    rng(123); % 固定随机种子，保证可重复性
    X_validate = LHD(XL, XU, n_validate);
    Y_validate_true = callobj(problem.f, X_validate);
    Y_validate_pred = predictor(X_validate, krig_model);
    
    if dim == 1
        % ========== 1D情况 ==========
        x = linspace(XL, XU, 500)';
        y_true = callobj(problem.f, x);
        y_pred = predictor(x, krig_model);
        
        figure('Name', model_name, 'NumberTitle', 'off', 'Position', [100, 100, 1000, 600]);
        
        % 主图：预测曲线
        plot(x, y_true, 'b-', 'LineWidth', 2, 'DisplayName', 'True Function'); hold on;
        plot(x, y_pred, 'r-', 'LineWidth', 2, 'DisplayName', 'Kriging Prediction');
        scatter(S, Y, 100, 'k', 'filled', 'DisplayName', 'Training Points');
        scatter(X_validate, Y_validate_true, 60, 'g', 'filled', 'DisplayName', 'Validation Points (True)');
        scatter(X_validate, Y_validate_pred, 40, 'm', '^', 'DisplayName', 'Validation Points (Predicted)');
        
        xlabel('x', 'FontSize', 12);
        ylabel('f(x)', 'FontSize', 12);
        title(sprintf('%s - Kriging Prediction with Validation', model_name), 'FontSize', 14);
        legend('Location', 'best');
        grid on;
        
        % 子图：验证点误差
        figure('Name', [model_name '_Validation'], 'NumberTitle', 'off', 'Position', [150, 150, 800, 400]);
        val_errors = Y_validate_pred - Y_validate_true;
        bar(val_errors, 'FaceColor', [0.7 0.3 0.3]);
        hold on;
        plot([0, n_validate+1], [0, 0], 'k--', 'LineWidth', 1.5);
        xlabel('Validation Point Index', 'FontSize', 12);
        ylabel('Prediction Error', 'FontSize', 12);
        title(sprintf('Validation Errors (RMSE = %.4e)', sqrt(mean(val_errors.^2))), 'FontSize', 12);
        grid on;
        
    elseif dim == 2
        % ========== 2D情况 ==========
        n_grid = 60;
        x1 = linspace(XL(1), XU(1), n_grid);
        x2 = linspace(XL(2), XU(2), n_grid);
        [X1, X2] = meshgrid(x1, x2);
        X_grid = [X1(:), X2(:)];
        
        % 预测
        Y_pred = predictor(X_grid, krig_model);
        Y_pred_surf = reshape(Y_pred, n_grid, n_grid);
        
        % 真实值
        Y_true = callobj(problem.f, X_grid);
        Y_true_surf = reshape(Y_true, n_grid, n_grid);
        
        % 创建图形窗口
        figure('Name', model_name, 'NumberTitle', 'off', 'Position', [50, 50, 1200, 800]);
        
        % 子图1：预测曲面
        subplot(2,2,1);
        surf(X1, X2, Y_pred_surf, 'EdgeColor', 'none', 'FaceAlpha', 0.9);
        colormap('jet'); colorbar;
        xlabel('x_1'); ylabel('x_2'); zlabel('Prediction');
        title(sprintf('%s - Predicted Surface', model_name));
        grid on; view(45, 30);
        
        % 子图2：真实曲面
        subplot(2,2,2);
        surf(X1, X2, Y_true_surf, 'EdgeColor', 'none', 'FaceAlpha', 0.9);
        colormap('jet'); colorbar;
        xlabel('x_1'); ylabel('x_2'); zlabel('f(x)');
        title('True Function Surface');
        grid on; view(45, 30);
        
        % 子图3：预测误差
        subplot(2,2,3);
        Y_error_surf = reshape(Y_pred - Y_true, n_grid, n_grid);
        surf(X1, X2, Y_error_surf, 'EdgeColor', 'none', 'FaceAlpha', 0.9);
        colormap('jet'); colorbar;
        xlabel('x_1'); ylabel('x_2'); zlabel('Error');
        title('Prediction Error');
        grid on; view(45, 30);
        
        % 子图4：训练点 + 验证点对比
        subplot(2,2,4);
        % 绘制验证点预测 vs 真实值
        hold on;
        plot(Y_validate_true, Y_validate_pred, 'bo', 'MarkerSize', 8, 'LineWidth', 1.5);
        plot([min(Y_validate_true), max(Y_validate_true)], ...
             [min(Y_validate_true), max(Y_validate_true)], 'r--', 'LineWidth', 1.5);
        xlabel('True Value', 'FontSize', 11);
        ylabel('Predicted Value', 'FontSize', 11);
        title(sprintf('Validation: Predicted vs True (RMSE=%.4e)', ...
            sqrt(mean((Y_validate_pred - Y_validate_true).^2))));
        grid on;
        axis equal;
        
        sgtitle(sprintf('%s - Kriging Model Analysis (%d validation points)', ...
            model_name, n_validate), 'FontSize', 14, 'FontWeight', 'bold');
        
    else
        error('Only 1D and 2D problems are supported. Current dimension: %d', dim);
    end
    
    % 显示验证指标
    fprintf('\n========== %s Validation Results ==========\n', model_name);
    fprintf('Validation Points: %d\n', n_validate);
    fprintf('RMSE: %.6e\n', sqrt(mean((Y_validate_pred - Y_validate_true).^2)));
    fprintf('MAE:  %.6e\n', mean(abs(Y_validate_pred - Y_validate_true)));
    fprintf('Max Error: %.6e\n', max(abs(Y_validate_pred - Y_validate_true)));
    fprintf('==========================================\n');
end