function bestlambda=OpbRPL(S,Y,k,a0,q,n)

%% Optimal regularization parameter
% k, a0, q, n
if nargin < 6
    n=20; 
end
if nargin < 5
   q=10^(1/2);
end
if nargin < 4
   a0=10^(-5);
end
if nargin < 3
    k = 5;
end

for i = 1:n+1
    % lambda
    lambda = a0*q^(i-1);
    % K折交叉验证
    mse = LPeBKfold(S,Y,k,lambda);
    CVscore(i)=mse;
end

[MinCVscore,j]=min(CVscore);
bestlambda = a0*q^(j-1);
disp(['Best lambda is ',num2str(bestlambda),'.'])

end