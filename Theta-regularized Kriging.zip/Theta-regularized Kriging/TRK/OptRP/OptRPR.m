function bestmu=OptRPR(S,Y,k,a0,q,n)
%% Copyright: Xuelin Xie (xl.xie@whu.edu.cn)
%% Optimal regularization parameter
% k, a0, q, n
if nargin < 6
    n=20; 
end
if nargin < 5
   q=10^(1/2);
end
if nargin < 4
   a0=10^(-5);
end
if nargin < 3
    k = 5;
end

for i = 1:n+1
    % mu
    mu = a0*q^(i-1);
    % K折交叉验证
    mse  = RPeTKfold(S,Y,k,mu);
    CVscore(i)= mse;
end

[MinCVscore,j]=min(CVscore);
bestmu = a0*q^(j-1);
disp(['Best mu is ',num2str(bestmu),'.'])

end