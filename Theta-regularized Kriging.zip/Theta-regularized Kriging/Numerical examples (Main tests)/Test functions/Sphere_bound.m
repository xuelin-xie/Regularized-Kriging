function [lx,lu]=Sphere_bound
d=4;
lx=-5.12*ones(1,d);
lu=5.12*ones(1,d);
end