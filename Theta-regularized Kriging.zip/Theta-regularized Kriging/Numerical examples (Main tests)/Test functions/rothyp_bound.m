function [ XL,XU ] = rothyp_bound
d=6;
XL=-1*ones(1,d);
XU=1*ones(1,d);

end