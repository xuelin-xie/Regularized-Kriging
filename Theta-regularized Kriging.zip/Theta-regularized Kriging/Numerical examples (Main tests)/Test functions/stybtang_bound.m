function [lx,lu]= stybtang_bound
d=24;
lx=0*ones(1,d);
lu=0.5*ones(1,d);
end