function [ XL,XU ] = rastrigin_bound
%GP_BOUND Summary of this function goes here
%   Detailed explanation goes here
d=2;
XL=0*ones(1,d);
XU=1.8*ones(1,d);

end