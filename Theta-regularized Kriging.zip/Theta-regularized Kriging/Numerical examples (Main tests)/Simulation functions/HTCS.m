function [y] = HTCS(xx)

x1 = xx(1);
x2 = xx(2);
x3 = floor(xx(3));

y = (2+x3)*x1^2*x2;

end
