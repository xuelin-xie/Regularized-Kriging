clc;
clear;
setdemorandstream(pi);
problem.f=@HTCS;  % HTCS/piston simulation function
[XL,XU]=HTCS_bound();  
bounds=[XL;XU];
dim=size(bounds,2); 
pointnum=100;

for i=1:10

%% Sample point and evaluation point
Samp=LHD(XL,XU,pointnum);  
RealY=callobj(problem.f,Samp);
Data=[Samp,RealY];
n=randsample(pointnum,pointnum*3/4,'false'); 
A=Data(n,:); % A training set
c=1:pointnum;
c(n)=[];
B=Data(c,:);% B testing set
S=A(:,1:end-1);
Y=A(:,end);
EX=B(:,1:end-1);
EY=B(:,end);

%% UK
krig1=buildKRG(S,Y);  
%% predicted values
UK= predictor(EX, krig1);
%% The evaluation index of the Kriging model 
UR2(i)=1-sum((EY -UK).*(EY-UK)) /sum((EY-mean(EY)).*(EY-mean(EY)));
URMSE1(i)=sqrt(sum((EY -UK).*(EY -UK)) /size(EY,1));
UMAE1(i)=sum(abs(EY -UK))/size(EY,1);

%% RT-LK
%% Obtain optimal parameters
RT_bestlambda=OptRPL(S,Y);
krig2=buildKRGLPeT(S,Y,RT_bestlambda); 
%% predicted values
RTLK= predictor(EX, krig2);
%% The evaluation index of the LK model
RTLR2(i)=1-sum((EY -RTLK).*(EY-RTLK)) /sum((EY-mean(EY)).*(EY-mean(EY)));
RTRMSE2(i)=sqrt(sum((EY -RTLK).*(EY -RTLK)) /size(EY,1));
RTMAE2(i)=sum(abs(EY -RTLK))/size(EY,1);

%% RT-RK
%% Obtain optimal parameters
RT_bestmu=OptRPR(S,Y);
krig3=buildKRGRPeT(S,Y,RT_bestmu);   
%% predicted values
RTRK= predictor(EX, krig3);
%% The evaluation index of the RK model
RTRR2(i)=1-sum((EY -RTRK).*(EY-RTRK)) /sum((EY-mean(EY)).*(EY-mean(EY)));
RTRMSE3(i)=sqrt(sum((EY -RTRK).*(EY -RTRK)) /size(EY,1));
RTMAE3(i)=sum(abs(EY -RTRK))/size(EY,1);

%% RT-EK
% Obtain optimal parameters
[CVmse,RT_bestalpha,RT_bestgamma] = EPTKGridSearch(S,Y,5);
krig4=buildKRGEPeT(S,Y,RT_bestalpha,RT_bestgamma);
%% predicted values
EK= predictor(EX, krig4);
%% The evaluation index of the EK model
RTER2(i)=1-sum((EY -EK).*(EY-EK)) /sum((EY-mean(EY)).*(EY-mean(EY)));
RTRMSE4(i)=sqrt(sum((EY -EK).*(EY -EK)) /size(EY,1));
RTMAE4(i)=sum(abs(EY -EK))/size(EY,1);

%% PB-LK
%% Obtain optimal parameters
PB_bestlambda=OpbRPL(S,Y);
krig5=buildKRGLPeB(S,Y,PB_bestlambda); 
%% predicted values
PBLK= predictor(EX, krig5);
%% The evaluation index of the LK model
PBLR2(i)=1-sum((EY -PBLK).*(EY-PBLK)) /sum((EY-mean(EY)).*(EY-mean(EY)));
PBRMSE2(i)=sqrt(sum((EY -PBLK).*(EY -PBLK)) /size(EY,1));
PBMAE2(i)=sum(abs(EY -PBLK))/size(EY,1);

%% PB-RK
%% Obtain optimal parameters
PB_bestmu=OpbRPR(S,Y);
krig6=buildKRGRPeB(S,Y,PB_bestmu);   
%% predicted values
PBRK= predictor(EX, krig6);
%% The evaluation index of the RK model
PBRR2(i)=1-sum((EY -PBRK).*(EY-PBRK)) /sum((EY-mean(EY)).*(EY-mean(EY)));
PBRMSE3(i)=sqrt(sum((EY -PBRK).*(EY -PBRK)) /size(EY,1));
PBMAE3(i)=sum(abs(EY -PBRK))/size(EY,1);

%% PB-EK
% Obtain optimal parameters
[CVmse,PB_bestalpha,PB_bestgamma] = EPBKGridSearch(S,Y,5);
krig7=buildKRGEPeB(S,Y,PB_bestalpha,PB_bestgamma);
%% predicted values
PBEK= predictor(EX, krig7);
%% The evaluation index of the EK model
PBER2(i)=1-sum((EY -PBEK).*(EY-PBEK)) /sum((EY-mean(EY)).*(EY-mean(EY)));
PBRMSE4(i)=sqrt(sum((EY -PBEK).*(EY -PBEK)) /size(EY,1));
PBMAE4(i)=sum(abs(EY -PBEK))/size(EY,1);
end

UR2,RTLR2,RTRR2,RTER2,PBLR2,PBRR2,PBER2
URMSE1,RTRMSE2,RTRMSE3,RTRMSE4,PBRMSE2,PBRMSE3,PBRMSE4
UMAE1,RTMAE2,RTMAE3,RTMAE4,PBMAE2,PBMAE3,PBMAE4

Means=[mean(UR2),mean(RTLR2),mean(RTRR2),mean(RTER2),mean(PBLR2),mean(PBRR2),mean(PBER2);
    mean(URMSE1),mean(RTRMSE2),mean(RTRMSE3),mean(RTRMSE4),mean(PBRMSE2),mean(PBRMSE3),mean(PBRMSE4);...
    mean(UMAE1),mean(RTMAE2),mean(RTMAE3),mean(RTMAE4),mean(PBMAE2),mean(PBMAE3),mean(PBMAE4)]

Std=[std(UR2),std(RTLR2),std(RTRR2),std(RTER2),std(PBLR2),std(PBRR2),std(PBER2);
    std(URMSE1),std(RTRMSE2),std(RTRMSE3),std(RTRMSE4),std(PBRMSE2),std(PBRMSE3),std(PBRMSE4);...
    std(UMAE1),std(RTMAE2),std(RTMAE3),std(RTMAE4),std(PBMAE2),std(PBMAE3),std(PBMAE4)]

% xlswrite('piston.xlsx',Means,1);
% xlswrite('piston.xlsx',Std,2);
